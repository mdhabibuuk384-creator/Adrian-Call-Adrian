# WaterDrop - Premium Android Calling App

WaterDrop is a production-grade, Android-only real-time audio and video calling application designed with an elegant Water Drop aesthetic, Jetpack Compose, Material 3, Firebase Authentication (SMS OTP), and native WebRTC.

## 🚀 Key Features
- **Fluid Water Drop Aesthetic**: Custom water-drop logo, ripple animations, cyan/aqua/navy color palette, dark/light modes.
- **Mobile Number Authentication**: SMS OTP with international support (+880 Bangladesh, +966 Saudi Arabia, etc.).
- **Real-Time WebRTC Audio & Video Calling**: 1080p video, front/rear camera switching, echo cancellation, noise suppression.
- **Android Telecom Integration**: Native Android call notifications, lockscreen overlay, and Bluetooth audio routing.
- **10 Original Water Drop Ringtones**: Built-in harmonic audio tones synthesized for incoming calls.

## 📱 Testing on Two Devices
1. Install the Debug APK on Device A and Device B.
2. Register Device A with `+880 1712-345678` and Device B with `+966 50 123 4567`.
3. In Device A, open Contacts or Search, select Device B, and tap the Audio Call or Video Call icon.
4. Device B will receive a high-priority heads-up call banner with the custom Water Drop ringtone.
5. Tap Accept to experience crystal-clear 2-way WebRTC calling!

## 🛠️ Build Commands
```bash
# Build Debug APK
./gradlew assembleDebug

# Build Production Release Android App Bundle (AAB)
./gradlew bundleRelease
```
